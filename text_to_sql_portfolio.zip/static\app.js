document.addEventListener('DOMContentLoaded', () => {
    // UI Elements
    const form = document.getElementById('query-form');
    const input = document.getElementById('query-input');
    const resultsContainer = document.getElementById('results-container');
    const loader = document.getElementById('loader');
    const dataView = document.getElementById('data-view');
    const errorView = document.getElementById('error-view');
    const errorMsg = document.getElementById('error-msg');
    const sqlCode = document.getElementById('sql-code');
    const sqlContainer = document.getElementById('sql-container');
    const toggleSqlBtn = document.getElementById('toggle-sql');
    const renderArea = document.getElementById('render-area');

    // Login Elements
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const loginModal = document.getElementById('login-modal');
    const closeModal = document.querySelector('.close-modal');
    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');
    const userProfile = document.getElementById('user-profile');
    const userNameDisplay = document.getElementById('user-name-display');

    // State
    let currentUser = null; // { id: 99, name: "Legal" }

    // --- LOGIN MODAL LOGIC ---
    loginBtn.addEventListener('click', () => {
        loginModal.classList.remove('hidden');
        loginError.classList.add('hidden');
    });

    closeModal.addEventListener('click', () => {
        loginModal.classList.add('hidden');
    });

    // Close modal if clicked outside
    window.addEventListener('click', (e) => {
        if (e.target == loginModal) {
            loginModal.classList.add('hidden');
        }
    });

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        loginError.classList.add('hidden');

        try {
            const response = await fetch('/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Credenciales inválidas');
            }

            // Success
            currentUser = data.user;
            loginModal.classList.add('hidden');
            loginBtn.classList.add('hidden');
            userProfile.classList.remove('hidden');
            userNameDisplay.innerHTML = `<i class="ph-fill ph-check-circle"></i> ${currentUser.name}`;
            loginForm.reset();

        } catch (err) {
            loginError.textContent = err.message;
            loginError.classList.remove('hidden');
        }
    });

    logoutBtn.addEventListener('click', () => {
        currentUser = null;
        userProfile.classList.add('hidden');
        loginBtn.classList.remove('hidden');
    });

    // --- QUERY LOGIC ---
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const question = input.value.trim();
        if (!question) return;

        // Mostrar estado de carga
        resultsContainer.classList.remove('hidden');
        loader.classList.remove('hidden');
        dataView.classList.add('hidden');
        errorView.classList.add('hidden');
        sqlContainer.classList.add('hidden');

        const payload = { question: question };
        if (currentUser) {
            payload.employee_id = currentUser.id;
        }

        try {
            const response = await fetch('/query', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Key': 'my-secret-token'
                },
                body: JSON.stringify(payload)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Ocurrió un error en el servidor');
            }

            // Exito: Renderizar resultados
            renderSuccess(data);

        } catch (error) {
            loader.classList.add('hidden');
            errorView.classList.remove('hidden');
            errorMsg.textContent = error.message;
        }
    });

    toggleSqlBtn.addEventListener('click', () => {
        sqlContainer.classList.toggle('hidden');
    });

    function renderSuccess(data) {
        loader.classList.add('hidden');
        dataView.classList.remove('hidden');
        sqlCode.textContent = data.generated_sql;
        renderArea.innerHTML = '';

        const records = data.data;

        if (!records || records.length === 0) {
            renderArea.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 2rem;">No se encontraron resultados.</p>';
            return;
        }

        // Detección automática de KPI
        const firstRow = records[0];
        const keys = Object.keys(firstRow);
        if (records.length === 1 && keys.length === 1 && typeof firstRow[keys[0]] === 'number') {
            renderKPI(keys[0], firstRow[keys[0]]);
        } else {
            renderTable(records);
        }
    }

    function renderKPI(label, value) {
        const div = document.createElement('div');
        div.className = 'kpi-card';
        div.innerHTML = `
            <div class="kpi-value">${value.toLocaleString()}</div>
            <div class="kpi-label">${label.replace('_', ' ')}</div>
        `;
        renderArea.appendChild(div);
    }

    function renderTable(records) {
        const wrapper = document.createElement('div');
        wrapper.className = 'table-wrapper';
        
        const table = document.createElement('table');
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        const keys = Object.keys(records[0]);
        
        keys.forEach(key => {
            const th = document.createElement('th');
            th.textContent = key.replace('_', ' ');
            headerRow.appendChild(th);
        });
        thead.appendChild(headerRow);
        table.appendChild(thead);

        const tbody = document.createElement('tbody');
        records.forEach(row => {
            const tr = document.createElement('tr');
            keys.forEach(key => {
                const td = document.createElement('td');
                const val = row[key];
                
                // Si el valor está enmascarado
                if (val === '****MASKED****') {
                    td.innerHTML = `<span class="masked-data">OCULTO</span>`;
                } else if (key.toLowerCase() === 'salary' || key.toLowerCase() === 'ssn') {
                    // Si es salario o ssn y NO está enmascarado (es decir, RLS permitió verlo)
                    td.innerHTML = `<span class="unmasked-data">${val}</span>`;
                } else {
                    td.textContent = val;
                }
                tr.appendChild(td);
            });
            tbody.appendChild(tr);
        });
        table.appendChild(tbody);

        wrapper.appendChild(table);
        renderArea.appendChild(wrapper);
    }
});

window.setQuery = function(text) {
    const input = document.getElementById('query-input');
    input.value = text;
};
